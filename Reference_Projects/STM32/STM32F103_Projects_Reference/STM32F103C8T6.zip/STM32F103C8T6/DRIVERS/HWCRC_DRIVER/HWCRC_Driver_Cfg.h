/*
 * HWCRC_Driver_Cfg.h
 *
 *  Created on: May 7, 2018
 *      Author: zsolt.balo
 */

#ifndef DRIVERS_HWCRC_DRIVER_HWCRC_DRIVER_CFG_H_
#define DRIVERS_HWCRC_DRIVER_HWCRC_DRIVER_CFG_H_

#include "HWCRC_Driver.h"

#define HWCRC_DRIVER_ENABLE					OK

#endif /* DRIVERS_HWCRC_DRIVER_HWCRC_DRIVER_CFG_H_ */
