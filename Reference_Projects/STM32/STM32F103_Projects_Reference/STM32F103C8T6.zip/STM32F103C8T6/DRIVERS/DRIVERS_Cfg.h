/*
 * DRIVERS_Cfg.h
 *
 *  Created on: Sep 5, 2018
 *      Author: zsolt.balo
 */

#ifndef DRIVERS_DRIVERS_CFG_H_
#define DRIVERS_DRIVERS_CFG_H_

/*Select the drivers which should be used*/


#endif /* DRIVERS_DRIVERS_CFG_H_ */
