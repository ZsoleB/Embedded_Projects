/*
 * SHIFT_REGISTER_Module_Cfg.c
 *
 *  Created on: Sep 18, 2018
 *      Author: zsolt.balo
 */

#include "SHIFT_REGISTER_Module_Cfg.h"

static SHIFT_REGISTER_Module_Setup_Type SHIFT_REGISTER_CONF_SETUP[SHIFT_REGISTER_INSTANCE_NUM];

SHIFT_REGISTER_Module_Setup_Type* SHIFT_REGISTER_SETUP = SHIFT_REGISTER_CONF_SETUP;

void SHIFT_REGISTER_Module_Init_Cfg()
{
	SHIFT_REGISTER_CONF_SETUP[SHIFT_REGISTER_MODULE_0].SPI_Instance = SPI_DRIVER_0;
}
